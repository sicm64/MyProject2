a=32
print a, hex(a),oct(a),bin(a)

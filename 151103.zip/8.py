a=[5,3,4,1,2]
a.index(2)
print a

a.count(5)
print a
a.sort()
print a
a.reverse()
print a
b=sorted(a)
print a
print b


colors = ['red', 'blue', 'green']
print colors[0]    
print colors[2]    
print len(colors)  

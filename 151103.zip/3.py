a = "abcde"
print a[0], a[4]		
print a[-1], a[-5]

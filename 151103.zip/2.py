a = 1.2			
b = 2.0			
print a. is_integer(), b.is_integer()	 
import math		 
print round(a), math.ceil(a), math.floor(a)
			 


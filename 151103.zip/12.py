s = set([1,2,3])
s.add(1)
print s
s.remove(1)
print s
s.update([1,4,5,6,7])
print s
s.discard(3)
print s
s.clear()
print s

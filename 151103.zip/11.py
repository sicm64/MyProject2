b="singu University"
a = list(b)

for i in range(len(a)):
    print a.pop()

a = "Gachon Unversity"
print a[0:6], " AND ", a[-9:]
print a[:] 
print a[-50:50] 
print a[::2], " AND ", a[::-1] 
